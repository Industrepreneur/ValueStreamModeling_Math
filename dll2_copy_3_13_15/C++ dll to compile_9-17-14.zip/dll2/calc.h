#ifndef _CALC_H // must be unique name in the project
#define _CALC_H

void   mpcalc ( class_model * c1 ); // prototype declaration of the function in a.cpp

#endif

