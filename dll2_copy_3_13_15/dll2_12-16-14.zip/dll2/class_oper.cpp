#include "StdAfx.h"
#include "class_oper.h"


class_oper::class_oper(void)
{
}


class_oper::~class_oper(void)
{
}
