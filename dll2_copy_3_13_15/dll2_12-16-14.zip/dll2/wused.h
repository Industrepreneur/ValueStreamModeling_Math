#include "class_part.h"
#include "class_ibom.h"

#pragma once
class class_wused
{
public:

	   class_part    * part_ptr;
       class_ibom    * cibom2_ptr;
	   int me_ptr;
        // next  item p_WUSED   * n_wused;


	class_wused(void);
	~class_wused(void);
};

