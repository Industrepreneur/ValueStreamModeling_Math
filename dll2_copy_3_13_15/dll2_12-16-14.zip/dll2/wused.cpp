#include "StdAfx.h"
#include "wused.h"


class_wused::class_wused(void)
{
}


class_wused::~class_wused(void)
{
}
