#include "StdAfx.h"
#include "class_ibom.h"


class_ibom::class_ibom(void)
{
}


class_ibom::~class_ibom(void)
{
}
