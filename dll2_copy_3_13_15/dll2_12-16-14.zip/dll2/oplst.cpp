#include "StdAfx.h"
#include "oplst.h"


class_oplst::class_oplst(void)
{
}


class_oplst::~class_oplst(void)
{
}
