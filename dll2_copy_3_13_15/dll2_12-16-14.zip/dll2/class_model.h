#pragma once
class class_model
{
public:
	class_model(void);
	~class_model(void);
};

